package com.hdw.mq.config;

public interface QueueConstants {


    String QUEUE_TEST = "test";

    String QUEUE_ENTERPRISE_DEVICES = "enterpriseDevices";
    String QUEUE_RYCS_QUEUE = "RYCSQueue";
    String QUEUE_RYCY_QUEUE = "RYCYQueue";
    String QUEUE_RYSB_QUEUE = "RYSBQueue";
    String QUEUE_RYSC_QUEUE = "RYSCQueue";
    String QUEUE_RYTZ_QUEUE = "RYTZQueue";
    String QUEUE_RYYC_QUEUE = "RYYCQueue";
    String QUEUE_SENSOR_DATA_QUEUE = "sensorDataQueue";
}
