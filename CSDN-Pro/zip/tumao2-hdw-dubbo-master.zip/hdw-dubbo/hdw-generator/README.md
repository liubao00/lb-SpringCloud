**项目说明** 
- hdw-generator是hdw-dubbo项目的代码生成器，可在线生成entity、xml、dao、service、html、js、sql代码，减少70%以上的开发任务
<br> 



 **本地部署**
- 修改application.yml，更新MySQL账号和密码、数据库名称
- 修改generator.properties，更新包名、表前缀
- Eclipse、IDEA运行GeneratorApplication.java，则可启动项目
- 项目访问路径：http://localhost:8183


