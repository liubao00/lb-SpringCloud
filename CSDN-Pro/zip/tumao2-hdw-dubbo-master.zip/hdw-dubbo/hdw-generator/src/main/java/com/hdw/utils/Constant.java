package com.hdw.utils;

/**
 * 常量
 * 
 * @Author TuMinglong
 * @email tuminglong@126.com
 * @Date  2018/12/21 14:17
 */
public class Constant {


}
