package com.hdw.common.validator.group;

import javax.validation.groups.Default;

/**
 * @Description 更新数据 Group
 * @Author TuMingLong
 * @Date 2019/11/4 11:24
 */
public interface UpdateGroup extends Default {
}
